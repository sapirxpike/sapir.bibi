
//function click() {
  //  console.log('hi function');
  //  document.getElementById("demo").innerHTML="hi js function!";
//}

function myfunction(){
var x , y , z ;
x=7;
y=5;
z=x+y;

var end ;
end = z**y;

var bool;
bool=(x==y);

console.log(end);
document.getElementById("demo2").innerHTML= end;
console.log(bool);


var user = {
    firstname: 'eli', 
    lastname: 'cohen' ,
    email: 'elicohen@gmail.com',
    age:25
}
console.log(user);
console.log(user.email);
}