

function namefunction(){
   // var String x  ;
   // x=sapir-bibi;
    
    
    //console.log(x);
   // document.getElementById("demo2").innerHTML= end;
    //console.log(bool);
    
    
   // var user = {
    //    firstname: 'eli', 
    //    lastname: 'cohen' ,
    //    email: 'elicohen@gmail.com',
    //    age:25
    //}
  //  console.log(user);
   // console.log(user.email);
    //}


    
var user = {
    firstname: 'sapir', 
    lastname: 'bibi' ,
   
}
console.log(user);

}