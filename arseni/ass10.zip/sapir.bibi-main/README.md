# sapir.bibi
