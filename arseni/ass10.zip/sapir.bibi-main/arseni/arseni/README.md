
#   https://github.com/sapirxpike/sapir.bibi.git
## go to arseni folder
# exersize 1 - Sapir Bibi

## assignment8




1. עברתי על כל המצגת ( שיעור שני של ארסני)
2. יצרתי תיקיית static
3. יצרתי תיקיית static
4. יצרתי תיקיית templates
5. קובץ APP.PY
6. קובץ README
7. הכנסתי לתיקיית טיימפלייט 5 קבצי HTML נפרדים: aboutme/base/CVgrid-exersize5/header/my_footer
8. הכנסתי תקיית static -  תיקיות : CSS/IMGS/JS
9. בתוך CSS הכנסתי את הCSS של Exersize5
10. בתוך APP.PY ארבעה ROUTES שונים :כאשר המרכזי מוביל לקורות חיים שלי ואחד נוסף לתקיית ABOUTME
11. בתוך APP.PY הגדרתי עבור הקובת ABOUT ME משתני שם ובנוסך רשימה עבור תואר
12. יצרתי בתקיית BASE 2 בלוקים מרכזיים - FOOTER ו CONTENT ובכל אחת מהתקייות באופן מודולרי מימשתי את קובץ BASE
13. בנוסך בתיקיית BASE מימשתי SUPER שמודגם גם בקורות חיים וגם בABOUT ME
14. בדף המקור CVgrid-exersize5 מימשתי תת דרך בכדי להגיע לכל אחד מן הדפים
15. בדך about me הגדרתי שורות קוד שמשתמשות במשתנים ובנוסף לולאה לטובת מודולריות למשתנה הDEGREE כמו שנלמד בהרצאה
16. עבור תקיית APP.PY הגדרתי תנאי IF לשם - כלומר במידה ויש שם ניתן לראות את המידע
17. בהמשך ההרצאות אדגים שימוש בהשמת סיסמא ושם לטובת כניסה לאתרי האינפורמציה 







